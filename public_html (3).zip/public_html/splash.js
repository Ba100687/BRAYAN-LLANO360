const codepen = document.getElementById('codepen');
codepen.addEventListener('click', () => {
  codepen.style.transform = 'scale(1.2)';
    codepen.style.animation = 'goldWave 0.5s ease-in-out'; 
  // Espera a que termine la animación y luego redirige a otra página
  setTimeout(() => {
    window.location.href = 'home.html'; // Cambia esto a la URL de la página a la que quieras redirigir
  }, 500); // 300 ms es la duración de la animación en milisegundos
});
