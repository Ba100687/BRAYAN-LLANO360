<?php
if (
    isset($_POST['nombre']) &&
    isset($_POST['telefono']) &&
    isset($_POST['email']) &&
    isset($_POST['servicio']) &&
    isset($_POST['personas']) &&
    isset($_POST['fecha_inicio']) &&
    isset($_POST['fecha_fin']) &&
    isset($_POST['precio_total'])
) {
    $subs_name = utf8_decode($_POST['nombre']);
    $subs_telefono = utf8_decode($_POST['telefono']);
    $subs_email = utf8_decode($_POST['email']);
    $subs_servicio = $_POST['servicio'];
    $subs_personas = utf8_decode($_POST['personas']);
    $subs_fecha_inicio = utf8_decode($_POST['fecha_inicio']);
    $subs_fecha_fin = utf8_decode($_POST['fecha_fin']);
    $precio_total = $_POST['precio_total'];  // No necesitas usar utf8_decode en este caso

 
    $conn = mysqli_connect("localhost", "id21330699_tesis_name", "Tesis@2023", "id21330699_tesis_db");

    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }


        // Insertar el nuevo registro
        $insert_query = "INSERT INTO `usuariospendientes`(`correo`, `nombre`, `telefono`, `servicio`, `num_personas`, `fecha_inico`, `fecha_fin`, `total`) VALUES ('$subs_email','$subs_name', '$subs_telefono', '$subs_servicio', '$subs_personas', '$subs_fecha_inicio', '$subs_fecha_fin', '$precio_total')";

        if (mysqli_query($conn, $insert_query)) {
            // Enviar el correo electrónico
                 //encargado
                  $to = "sebastianmacana8@gmail.com";
                  $subject = "Solicitud de Atencion Personalizada";   
                  $message = "Se ha Realizado una nueva Cotizacion:" .
                        "\nNombre: $subs_name," .
                        "\nTeléfono: $subs_telefono, " .
                        "\nCorreo: $subs_email," .
                        "\nServicio: $subs_servicio," .
                        "\nNumero de personas: $subs_personas," .
                        "\nFecha de inicio: $subs_fecha_inicio," .
                        "\nFecha de fin: $subs_fecha_fin," .
                        "\nTotal: $precio_total,";

                 
                 //cliente
                  $tocliente = $subs_email;
                  $subjectcliente = "Cotizacion Llano360security";
                  $messagecliente = "Hola Sr(@): $subs_name, Se ha registrado su cotizacion.";
                  $headers = "From: llano360security@tesis.com";
                    
                  mail($to, $subject, $message, $headers);
                  mail($tocliente, $subjectcliente, $messagecliente, $headers);
                    
            $message = "Registro insertado correctamente, correo enviado.";
            $redirect = "https://llano360security.000webhostapp.com/home.html";
        } else {
            $message = "Error al insertar el registro: " . mysqli_error($conn);
            $redirect = "https://llano360security.000webhostapp.com/formulario.html";
        }
    

    mysqli_close($conn);

    // Redirigir después de haber terminado con las operaciones
    echo "<script>
        alert('$message');
        window.location.href = '$redirect';
    </script>";
} else {
    echo "Ingrese todos los campos.";
}
?>













































