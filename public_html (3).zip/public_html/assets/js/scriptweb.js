
// smooth scroll desde nav
$(document).ready(function(){
    $(".navbar .nav-link ").on('click', function(event) {

        if (this.hash !== "") {

            event.preventDefault();

            var hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top
            }, 700, function(){
                window.location.hash = hash;
            });
        } 
    });
});


// smooth scroll desde porque elegirnos
document.addEventListener("DOMContentLoaded", function() {
  var overlayLinks = document.querySelectorAll(".gallary-overlay");

  overlayLinks.forEach(function(link) {
    link.addEventListener("click", function(event) {
      event.preventDefault();

      var targetId = this.getAttribute("href");
      var targetElement = document.querySelector(targetId);

      if (targetElement) {
        targetElement.scrollIntoView({ behavior: "smooth" });
      }
    });
  });
});


// smooth scroll desde boton
document.addEventListener("DOMContentLoaded", function() {
  var scrollBtn = document.getElementById("scrollBtn");
  var gallarySection = document.getElementById("gallary");

  scrollBtn.addEventListener("click", function(event) {
    event.preventDefault();

    gallarySection.scrollIntoView({ behavior: "smooth" });
  });
});

//gooogle maps
new WOW().init();
function initMap() {
    var uluru = {lat: 4.144032803097613, lng: -73.63407429193454};
    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 10,
      center: uluru
    });
    var marker = new google.maps.Marker({
      position: uluru,
      map: map
    });
 }

 //sombra al navbar al hacer scroll
const navbar = document.querySelector('.custom-navbar');

window.addEventListener('scroll', () => {
  if (window.scrollY > 0) {
    navbar.classList.add('scrolled', 'with-shadow'); // Agregar ambas clases
  } else {
    navbar.classList.remove('scrolled', 'with-shadow'); // Eliminar ambas clases
  }
});

